// src/components/EditUser.js
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import '../App.css';

const BASE_URL = 'https://reqres.in/api';

function EditUser() {
    const navigate = useNavigate();
    const location = useLocation();
    const { user } = location.state;
    const [firstName, setFirstName] = useState(user.first_name);
    const [lastName, setLastName] = useState(user.last_name);
    const [email, setEmail] = useState(user.email);

    const handleUpdate = async () => {
        try {
            await axios.put(`${BASE_URL}/users/${user.id}`, { first_name: firstName, last_name: lastName, email });
            navigate('/users');
        } catch (err) {
            console.error('Failed to update user');
        }
    };

    return (
        <div className="edit-container">
            <h2>Edit User</h2>
            <input value={firstName} onChange={(e) => setFirstName(e.target.value)} />
            <input value={lastName} onChange={(e) => setLastName(e.target.value)} />
            <input value={email} onChange={(e) => setEmail(e.target.value)} />
            <button onClick={handleUpdate}>Update</button>
        </div>
    );
}

export default EditUser;
