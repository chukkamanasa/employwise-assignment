// src/components/Users.js
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../App.css';

const BASE_URL = 'https://reqres.in/api';

function Users() {
    const navigate = useNavigate();
    const [users, setUsers] = useState([]);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);

    const fetchUsers = async (page) => {
        try {
            const response = await axios.get(`${BASE_URL}/users?page=${page}`);
            setUsers(response.data.data);
            setTotalPages(response.data.total_pages);
        } catch (err) {
            console.error('Failed to fetch users');
        }
    };

    useEffect(() => {
        fetchUsers(page);
    }, [page]);

    const handleLogout = () => {
        localStorage.removeItem('token');
        navigate('/');
    };

    const handleDelete = async (id) => {
        try {
            await axios.delete(`${BASE_URL}/users/${id}`);
            setUsers(users.filter(user => user.id !== id));
        } catch (err) {
            console.error('Failed to delete user');
        }
    };

    const handleEdit = (user) => {
        navigate(`/edit/${user.id}`, { state: { user } });
    };

    return (
        <div className="users-container">
            <h2>Users List</h2>
            <button onClick={handleLogout}>Logout</button>
            <div className="user-list">
                {users.map(user => (
                    <div key={user.id} className="user-card">
                        <img src={user.avatar} alt={user.first_name} />
                        <p>{user.first_name} {user.last_name}</p>
                        <button onClick={() => handleEdit(user)}>Edit</button>
                        <button onClick={() => handleDelete(user.id)}>Delete</button>
                    </div>
                ))}
            </div>
            <div className="pagination">
                <button disabled={page === 1} onClick={() => setPage(page - 1)}>Prev</button>
                <span>Page {page} of {totalPages}</span>
                <button disabled={page === totalPages} onClick={() => setPage(page + 1)}>Next</button>
            </div>
        </div>
    );
}

export default Users;
